create view estadistica(nom_c, num_p, pobl, alt_mitjana) as
SELECT poblacio.nom_c,
       count(poblacio.nom)    AS num_p,
       sum(poblacio.poblacio) AS pobl,
       avg(poblacio.altura)   AS alt_mitjana
FROM poblacio
GROUP BY poblacio.nom_c
ORDER BY poblacio.nom_c;

alter table estadistica
    owner to geo_ad;

