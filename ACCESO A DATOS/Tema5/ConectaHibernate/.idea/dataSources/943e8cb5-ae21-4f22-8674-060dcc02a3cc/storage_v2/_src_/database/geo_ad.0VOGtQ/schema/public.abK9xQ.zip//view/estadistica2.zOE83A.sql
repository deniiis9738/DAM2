create view estadistica2(nom_c, provincia) as
SELECT comarca.nom_c,
       comarca.provincia
FROM comarca;

alter table estadistica2
    owner to geo_ad;

