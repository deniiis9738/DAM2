create function listaprsonas(comodin character varying) returns SETOF usuarios
    language plpgsql
as
$$
    declare
        reg record;
    begin
        for reg in select * from usuarios where nombre like comodin loop
            reg.nombre := reg.nombre;
            return next reg;
        end loop;
        return;
    end;
    $$;

alter function listaprsonas(varchar) owner to postgres;

