create function cantidadpersonas(comodin character varying) returns integer
    language plpgsql
as
$$
    declare
        cantidad integer;
    begin
        select count(*) into cantidad from personas where nombre like comodin;
        return cantidad;
    end;
$$;

alter function cantidadpersonas(varchar) owner to postgres;

