create function cantidadtotalpersonas() returns integer
    language plpgsql
as
$$
    declare
        cantidad integer;
    begin
        select count(*) into cantidad from usuarios;
        return cantidad;
    end;
    $$;

alter function cantidadtotalpersonas() owner to postgres;

