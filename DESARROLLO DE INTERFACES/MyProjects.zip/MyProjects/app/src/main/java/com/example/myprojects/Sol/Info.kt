package com.example.sol

import androidx.compose.runtime.Composable

@Composable
fun Info() {

}