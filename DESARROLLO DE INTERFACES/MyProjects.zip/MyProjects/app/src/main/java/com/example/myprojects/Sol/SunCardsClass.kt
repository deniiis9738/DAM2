package com.example.sol

class SunCardsClass(val image: Int, val text: String)