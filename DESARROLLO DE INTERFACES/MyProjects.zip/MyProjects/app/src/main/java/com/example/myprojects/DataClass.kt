package com.example.myprojects

import androidx.compose.ui.graphics.vector.ImageVector

class DataClass(val image: ImageVector, val text: String, val route: String)